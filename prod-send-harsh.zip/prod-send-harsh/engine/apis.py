import calendar
import csv
import logging
import random
from datetime import date, timedelta
import editdistance
import xmltodict
import pandas as pd
import math
import requests
import json
import uuid
import datetime
import socket

from pprint import pprint
from bs4 import BeautifulSoup

from django.conf import settings
from django.http import HttpResponse
from django.utils.encoding import smart_str
from rest_framework.authentication import (BasicAuthentication,
										   SessionAuthentication)
from rest_framework.response import Response
from django.shortcuts import render, get_object_or_404
from rest_framework.views import APIView
from django.core.mail import EmailMultiAlternatives
from django.utils.safestring import SafeData, SafeText, mark_safe
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.views import generic
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator

from .models import *
from .constants import *
from .parsers import *

def call_api(input_query):
	s = socket.socket()
	port = 5161
	ip = "10.50.81.179"
	s.connect((ip,port))
	s.sendall(input_query)
	output_string = ""
	while True:    
		data = s.recv(1024)        
		if not data: 
			break
		output_string += data
	s.close()
	return output_string

def call_grid_api(mobile_number, account_number, d1, d2, d3, d4, d5, d6):
	input_query = """
	"""
def get_user_id(mobile_number):
	input_query = """<XML>
				   <MessageType>1200</MessageType>
				   <ProcCode>E00011</ProcCode>
				   <LocalTxnDtTime>20060215034205</LocalTxnDtTime>
				   <Identifier>MA</Identifier>
				   <MobileNo>"""+mobile_number+"""</MobileNo>
				   <UserID></UserID>
				   <DeliveryChannelCtrlID>TLB</DeliveryChannelCtrlID>
				   </XML>"""
	response = call_api(input_query)
	print("Reponse is: ", response)
	print("\n")
	user_id = parse_user_id(response)
	print(user_id)
	return user_id 
	
def get_grid_response(mobile_number, account_number, val1, val2, val3):
	#user_id = get_user_id(mobile_number)
	#user_id = "1212"
	input_query = """<XML>
				<ProcCode>plugin5001</ProcCode>
				<MessageType>1200</MessageType>
				<DeliveryChannelCtrlId>RIB</DeliveryChannelCtrlId>
				<LocalDateTimeStamp>20150315130211</LocalDateTimeStamp>
				<STAN>202304</STAN>
				<inputtype>A</inputtype>
				<input>"""+account_number+"""</input>
			<validation>
				<value offset="13">"""+val1[0]+"""</value>
				<value offset="14">"""+val1[1]+"""</value>
				<value offset="23">"""+val2[0]+"""</value>
				<value offset="24">"""+val2[1]+"""</value>
				<value offset="25">"""+val3[0]+"""</value>
				<value offset="26">"""+val3[1]+"""</value>
			</validation>
			 <REMARK></REMARK>
			</XML>"""

	response = call_api(input_query)
	print(response)
	#account_numbers = parse_account_numbers(response)
	actcode = parse_otp_send(response)
	print("ACT CODE IS: ", actcode)
	
	return actcode
def get_list_of_payees(mobile_number, type_of_connection):
	#user_id = get_user_id(mobile_number)
	user_id = "RIB11XTEST"
	input_query = """<XML>
	<HEADER>UBPS</HEADER>
	<MessageType>1200</MessageType>
	<ProcCode>960800</ProcCode>
	<TxnAmt>0</TxnAmt>
	<STAN>20141216006</STAN>
	<LocalTxnDtTime>00180207075531</LocalTxnDtTime>
	<CaptureDt>20180207</CaptureDt>
	<FuncCode>200</FuncCode>
	<AcqInstIdenCode>504642</AcqInstIdenCode>
	<Identification1>"""+user_id+"""</Identification1>
	<Currency>INR</Currency>
	<ConsumerNo />
	<AcctIdentificationOne>                                      </AcctIdentificationOne>
	<DeliveryChannelCtrlID>IMB</DeliveryChannelCtrlID>
	<AddDataPvt125>
		<UbpsReqTyp>08</UbpsReqTyp>
		<PayeeID />
		<InstancePymntDate />
		<ScheduleId></ScheduleId>
		<NoOfPayements>12</NoOfPayements>
		<PaymentType>P</PaymentType>
	</AddDataPvt125>
</XML>"""
	print("Request payee id is: ", input_query)
	response = call_api(input_query)
	print(response)
	payee_ids = parse_payee_ids_amount(response, "P")
	print(payee_ids)
	return payee_ids
		
def get_list_of_connections(mobile_number):
	#user_id = get_user_id(mobile_number)
	user_id = "RIB11XTEST"
	input_query = """<XML>
	<HEADER>UBPS</HEADER>
	<MessageType>1200</MessageType>
	<ProcCode>960800</ProcCode>
	<TxnAmt>0</TxnAmt>
	<STAN>20141216006</STAN>
	<LocalTxnDtTime>00180207075531</LocalTxnDtTime>
	<CaptureDt>20180207</CaptureDt>
	<FuncCode>200</FuncCode>
	<AcqInstIdenCode>504642</AcqInstIdenCode>
	<Identification1>"""+user_id+"""</Identification1>
	<Currency>INR</Currency>
	<ConsumerNo />
	<AcctIdentificationOne>                                      </AcctIdentificationOne>
	<DeliveryChannelCtrlID>IMB</DeliveryChannelCtrlID>
	<AddDataPvt125>
		<UbpsReqTyp>08</UbpsReqTyp>
		<PayeeID />
		<InstancePymntDate />
		<ScheduleId></ScheduleId>
		<NoOfPayements>12</NoOfPayements>
		<PaymentType>P</PaymentType>
	</AddDataPvt125>
</XML>"""
	print("Request payee id is: ", input_query)
	response = call_api(input_query)
	print(response)
	payee_ids = parse_payee_ids(response)
	print("Payee ids are: ", payee_ids)
	list_different_connections = []
	for i in range(len(payee_ids)):
		payee_ids[i] = payee_ids[i].lstrip('0')
	set_payee = set(payee_ids)
	print(set_payee)
	for payee_id in set_payee:
		try:
			print(payee_id)
			a = BillApiCustom.objects.filter(payee_id=payee_id)[0] 
			print(a)
			list_different_connections.append(a.payee_type)
			print(a)
		except:
			pass
	print(list_different_connections)
	return list_different_connections
	
def get_account_numbers_original(mobile_number):
	user_id = get_user_id(mobile_number)
	#user_id = "1212"
	input_query = """<XML>
					 <MessageType>1104</MessageType>
					 <ProcCode>916000</ProcCode>
					 <STAN>020202020202</STAN>
					 <LocalTxnDtTime>20090903105241</LocalTxnDtTime>
					 <FuncCode>200</FuncCode>
					 <PvtDataField48>
					 <UserID>"""+user_id+"""</UserID>
					 </PvtDataField48>
					 <TxnDestnCode>3</TxnDestnCode>
					 <TxnOrigCode>8</TxnOrigCode>
					 <DeliveryChannelCtrlID>ACS</DeliveryChannelCtrlID>
					 </XML>"""
	response = call_api(input_query)
	print(response)
	account_numbers = parse_account_numbers(response)
	print("Account numbers are: ", account_numbers)
	#account_numbers = ["12800000001","12800000002"]
	return account_numbers
	
def get_account_numbers(mobile_number):    
	user_id = get_user_id(mobile_number)
	#user_id = "1212"
	input_query = """<XML>
					 <MessageType>1104</MessageType>
					 <ProcCode>916000</ProcCode>
					 <STAN>020202020202</STAN>
					 <LocalTxnDtTime>20090903105241</LocalTxnDtTime>
					 <FuncCode>200</FuncCode>
					 <PvtDataField48>
					 <UserID>"""+user_id+"""</UserID>
					 </PvtDataField48>
					 <TxnDestnCode>3</TxnDestnCode>
					 <TxnOrigCode>8</TxnOrigCode>
					 <DeliveryChannelCtrlID>ACS</DeliveryChannelCtrlID>
					 </XML>"""
	response = call_api(input_query)
	account_numbers = parse_account_numbers(response)
	for i in range(len(account_numbers)):
		acc_temp = account_numbers[i][-4:]
		acc_temp = "@".join(acc_temp)
		account_numbers[i] = "ending in " + acc_temp
	#account_numbers = ["ending in 3@4@1@2","ending in 4@5@1@2"]
	print("Account numbers are : ", account_numbers)
	return account_numbers

def pay_credit_card_bill(mobile_number, credit_card_number, account_number):
	user_id = get_user_id(mobile_number)
	#user_id = "1212"
	txn_due, txn_amount = get_credit_card_details(credit_card_number, mobile_number)
	#txn_amount = "1000"
	account_number = "ICI"+"        "+account_number[0:4]+"    "+account_number
	print("Account number is ", account_number)
	print("Amount due is: ", txn_amount)

	last_4_digit = ""
	for d in credit_card_number:
		print(d)
		if d.isdigit():
			last_4_digit+=d
	print("Last 4 ditits", last_4_digit)
	credit_card_numbers = get_credit_card_numbers_original(mobile_number)
	print("NNNNNNNNNNNNNNN", credit_card_numbers)
	for cc in credit_card_numbers:        
		if cc[-4:] == last_4_digit:
			credit_card_number = cc

	input_query = """
	<XML>
	<HEADER MSGFORMATID="157" PASSTHROUGH="N" ROUTEHOSTTYPE="UBPS" ROUTETO="UBPS" SCRIPTNAME="com.mphasis.businessScripts.bin.ChangeAttribute"></HEADER>
	<MessageType DEFAULT="1200" DT="numeric" LSP="0" MNL="4" MXL="4" PL="4" PRE="mandatory">1200</MessageType>
	<ProcCode DEFAULT="961100" DT="numeric" IND="3" LSP="0" MNL="6" MXL="6" PL="6" PRE="mandatory">961100</ProcCode>
	<TxnAmt DT="numeric" IND="4" LSP="0" MNL="16" MXL="16" PL="16" PRE="optional">"""+txn_amount+"""</TxnAmt>
	<STAN DT="alphabetnumericspaces" IND="11" LSP="0" MNL="12" MXL="12" PL="12" PRE="mandatory">002064724924</STAN>
	<LocalTxnDtTime DT="numeric" IND="12" LSP="0" MNL="14" MXL="14" PL="14" PRE="mandatory">20180207202344</LocalTxnDtTime>
	<CaptureDt DT="date" IND="17" LSP="0" MNL="8" MXL="8" PL="8" PRE="optional">20180207</CaptureDt>
	<FuncCode DT="numeric" IND="24" LSP="0" MNL="3" MXL="3" PL="" PRE="mandatory">200</FuncCode>
	<AcqInstIdenCode DT="numeric" IND="32" LSP="2" MNL="1" MXL="11" PL="" PRE="mandatory">504642</AcqInstIdenCode>
	<Identification1 MXL="28" MNL="1" DT="alphabetnumeric" PL="" LSP="2" IND="34" PRE="mandatory">"""+user_id+"""</Identification1>
	<RRNNumber DT="numeric" IND="37" LSP="0" MNL="12" MXL="12" PL="12" PRE="mandatory">120809133559</RRNNumber>
	<CardAccTerminalID DT="alphabetnumericspaces" IND="41" LSP="0" MNL="16" MXL="16" PL="16" PRE="optional">UBPS</CardAccTerminalID>
	<CardAccIdentification DT="alphabetnumericspaces" IND="42" LSP="0" MNL="15" MXL="15" PL="15" PRE="optional">504642</CardAccIdentification>
	<CardAccNameLocation DT="alphabetnumericspaces" IND="43" LSP="2" MNL="1" MXL="99" PL="" PRE="optional">UBPS</CardAccNameLocation>
	<Currency DT="alphabetnumeric" IND="49" LSP="0" MNL="3" MXL="3" PL="" PRE="mandatory">INR</Currency>
	<PrivateField DT="alphabetnumericspecialspaces" IND="60" LSP="3" MNL="01" MXL="999" PL="" PRE="optional"></PrivateField>
	<PrivateField2 DT="alphabetnumericspecialspaces" IND="61" LSP="3" MNL="01" MXL="999" PL="" PRE="optional"></PrivateField2>
	<ConsumerNumber DT="alphabetnumericspecialspaces" IND="63" LSP="3" MNL="01" MXL="999" PL="" PRE="optional">"""+credit_card_number+"""</ConsumerNumber>
	<AcctIdentificationOne DT="alphabetnumericspecialspaces" IND="102" LSP="2" MNL="01" MXL="38" PL="" PRE="mandatory">"""+account_number+"""</AcctIdentificationOne>
	<DeliveryChannelCtrlID DT="alphabet" IND="123" LSP="3" MNL="1" MXL="3" PL="" PRE="mandatory">IMB</DeliveryChannelCtrlID>
	<AddDataPvt125 DT="alphabetnumericspecialspaces" IND="125" LSP="3" MNL="1" MXL="999" PL="" PRE="optional" RLI="0">
		<UbpsReqTyp DT="alphabetnumeric" IND="125" LSP="0" MNL="2" MXL="2" PL="" PRE="optional">11</UbpsReqTyp>
		<ScheduleBegngDate DT="alphabetnumericspaces" IND="125" LSP="0" MNL="8" MXL="8" PL="" PRE="optional">00000000</ScheduleBegngDate>
		<PayementFrequency DT="numeric" IND="125" LSP="0" MNL="1" MXL="1" PL="" PRE="optional">0</PayementFrequency>
		<TotNoOfPymnts DT="numeric" IND="125" LSP="0" MNL="5" MXL="5" PL="" PRE="optional">01</TotNoOfPymnts>
		<PayeeID DT="alphabetnumericspecialspaces" IND="125" LSP="0" MNL="12" MXL="12" PL="" PRE="optional">000000001232</PayeeID>
		<PaymntRemrks DT="alphabetnumericspecialspaces" IND="125" LSP="0" MNL="254" MXL="254" PL="" PRE="optional"></PaymntRemrks>
		<BillRefInfo DT="alphabetnumericspecialspaces" IND="125" LSP="0" MNL="254" MXL="254" PL="" PRE="optional"></BillRefInfo>
		<ValidationFlag DT="alphabetnumericspecialspaces" IND="125" LSP="0" MNL="1" MXL="1" PL="" PRE="optional">A</ValidationFlag>
		<PersonalPayee DT="alphabetnumericspecialspaces" IND="125" LSP="0" MNL="1" MXL="1" PL="" PRE="optional"></PersonalPayee>
		<PayeeNick DT="alphabetnumericspecialspaces" IND="125" LSP="0" MNL="40" MXL="40" PL="" PRE="optional"></PayeeNick>
		<ConsumerCode DT="alphabetnumericspecialspaces" IND="125" LSP="0" MNL="64" MXL="64" PL="" PRE="optional">"""+credit_card_number+"""</ConsumerCode>
	</AddDataPvt125>
</XML>
	"""
	input_query = input_query.replace("\n","")
	print("Request packet is: ", input_query)
	response = call_api(input_query)    
	print("Request is: ", input_query)
	print("\n\n\n")
	print("Response is: ", response)
	acct_code = parse_pay_creditcard_bill(response)
	print("Acct code is: ", acct_code)
	return acct_code

def get_credit_card_details(credit_card_number, mobile_number):
	last_4_digit = ""
	for d in credit_card_number:
		print(d)
		if d.isdigit():
			last_4_digit+=d
	print("Last 4 ditits", last_4_digit)
	credit_card_numbers = get_credit_card_numbers_original(mobile_number)
	print("NNNNNNNNNNNNNNN", credit_card_numbers)
	for cc in credit_card_numbers:
		if cc[-4:] == last_4_digit:
			credit_card_number = cc
	print("Num is: ", credit_card_number)
	input_query = """<XML><MessageType MXL='4' MNL='4' PL='4' DT='numeric' LSP='0' PRE='mandatory' DEFAULT='1200'>1200</MessageType><CustID MXL='19' MNL='19' DT='numeric' PL='19' LSP='0' IND='2' PRE='mandatory'>"""+credit_card_number+"""</CustID><ProcCode MXL='6' MNL='6' PL='6' DT='numeric' LSP='0' IND='3' PRE='mandatory' DEFAULT='610000'>610000</ProcCode><TxnAmt MXL='16' MNL='16' DT='numeric' PL='16' LSP='0' IND='4' PRE='mandatory'>1</TxnAmt><STAN MXL='6' MNL='6' DT='numeric' PL='6' LSP='0' IND='11' PRE='mandatory'>123456</STAN><LocalTxnDtTime MXL='12' MNL='12' DT='numeric' PL='12' LSP='0' IND='12' PRE='mandatory'>20180129152948</LocalTxnDtTime><CaptureDt MXL='8' MNL='8' DT='numeric' PL='' LSP='0' IND='17' PRE='mandatory'>19991015</CaptureDt><FuncCode MXL='3' MNL='3' DT='numeric' PL='' LSP='0' IND='24' PRE='mandatory' OVERRIDE='200'>200</FuncCode><AcqInstIdenCode MXL='11' MNL='1' DT='numeric' PL='' LSP='2' IND='32' PRE='mandatory' OVERRIDE='010'>001</AcqInstIdenCode><Currency MXL='3' MNL='3' DT='alphabet' PL='' LSP='0' IND='49' PRE='mandatory' DEFAULT='INR'>INR</Currency><FaxNo MXL='999' MNL='1' DT='alphabetnumericspecialspaces' PL='' LSP='3' IND='59' PRE='optional' /><FourDigitYear MXL='999' MNL='1' DT='alphabetnumericspecial' PL='' LSP='3' IND='62' PRE='mandatory'>1999</FourDigitYear><ConsumerNo MXL='28' MNL='1' DT='alphabetnumericspaces' PL='' LSP='2' IND='63' PRE='optional'>1</ConsumerNo><AcctIdentificationOne MXL='38' MNL='1' DT='alphabetnumericspaces' PL='' LSP='2' IND='102' PRE='mandatory'>"""+credit_card_number+"""</AcctIdentificationOne><DeliveryChannelCtrlID MXL='3' MNL='3' DT='alphabet' PL='' LSP='0' IND='123' PRE='mandatory' OVERRIDE='INT'>CCI</DeliveryChannelCtrlID><AddDataPvt125 MXL='999' MNL='1' DT='alphabetnumericspecialspaces' PL='' LSP='3' IND='125' RLI='0' PRE='optional'><RecordFrom MXL='999' MNL='1' DT='numeric' PRE='optional' PL='' LSP='1' IND='125'>1</RecordFrom><NoofRecordRequested MXL='99' MNL='1' DT='numeric' PRE='optional' PL='' LSP='1' IND='125'>16</NoofRecordRequested></AddDataPvt125></XML>"""
	print("Request is ", input_query)
	response = call_api(input_query)
	print("Request is: ", input_query)
	print("Response is: ", response)
	print("Okay")
	due_date, due_amount = parse_cc_date_amount(response)
	print("\n")
	print(due_date, due_amount)
	#due_date = "04/04/2016"
	#due_amount = "123213"

	return (due_date, due_amount)

def get_credit_card_numbers_original(mobile_number):
	user_id = get_user_id(mobile_number)
	#user_id = "MONU141"
	input_query = """<XML>
					 <MessageType>1104</MessageType>
					 <ProcCode>916000</ProcCode>
					 <STAN>020202020202</STAN>
					 <LocalTxnDtTime>20090903105241</LocalTxnDtTime>
					 <FuncCode>200</FuncCode>
					 <PvtDataField48>
					 <UserID>"""+user_id+"""</UserID>
					 </PvtDataField48>
					 <TxnDestnCode>3</TxnDestnCode>
					 <TxnOrigCode>8</TxnOrigCode>
					 <DeliveryChannelCtrlID>ACS</DeliveryChannelCtrlID>
					 </XML>"""
	response = call_api(input_query)
	creditcard_numbers = parse_credit_card_numbers(response)
	#creditcard_numbers = ["12121212"]
	print("Credit card numbers are: ", creditcard_numbers)
	return creditcard_numbers

def get_credit_card_numbers(mobile_number):
	user_id = get_user_id(mobile_number)
	#user_id = "MONU141"
	input_query = """<XML>
					 <MessageType>1104</MessageType>
					 <ProcCode>916000</ProcCode>
					 <STAN>020202020202</STAN>
					 <LocalTxnDtTime>20090903105241</LocalTxnDtTime>
					 <FuncCode>200</FuncCode>
					 <PvtDataField48>
					 <UserID>"""+user_id+"""</UserID>
					 </PvtDataField48>
					 <TxnDestnCode>3</TxnDestnCode>
					 <TxnOrigCode>8</TxnOrigCode>
					 <DeliveryChannelCtrlID>ACS</DeliveryChannelCtrlID>
					 </XML>"""
	response = call_api(input_query)
	print("Response is: ", response)
	creditcard_numbers = parse_credit_card_numbers(response)
	print("nums are :", creditcard_numbers)
	for i in range(len(creditcard_numbers)):
		credit_card_temp = creditcard_numbers[i][-4:]
		credit_card_temp = "@".join(credit_card_temp)
		print("credit_card_temp is: ", credit_card_temp)
		creditcard_numbers[i] = "ending in " + credit_card_temp
	#creditcard_numbers = ["ending in 9@1@1@3","ending in 1@2@3@1"]
	print(creditcard_numbers)
	return creditcard_numbers
	
def get_balance(account_number, mobile_number):
	print("Account number is: ", account_number, mobile_number)  
	last_4_digit = ""
	for d in account_number:
		print(d)
		if d.isdigit():
			last_4_digit+=d
	print("Last 4 ditits", last_4_digit)
	account_numbers = get_account_numbers_original(mobile_number)
	for acc in account_numbers:
		if acc[-4:] == last_4_digit:
			account_number = acc
	print(account_number,"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")
	acc_num = "ICI"+"        "+account_number[0:4]+"    "+account_number
	input_query = """<XML><MessageType DEFAULT="1200" DT="numeric" LSP="0" MNL="4" MXL="4" PL="4" PRE="mandatory">1200</MessageType><CustID DT="numeric" IND="2" LSP="2" MNL="1" MXL="19" PL="19" PRE="optional">"""+account_number+"""</CustID><ProcCode DEFAULT="380000" DT="numeric" IND="3" LSP="0" MNL="6" MXL="6" PL="6" PRE="mandatory">380000</ProcCode><AuthNum DT="alphabetnumericspaces" IND="11" LSP="0" MNL="12" MXL="12" PL="12" PRE="mandatory">0</AuthNum><LocalTxnDtTime DT="numeric" IND="12" LSP="0" MNL="14" MXL="14" PL="14" PRE="mandatory">20180510031525</LocalTxnDtTime><CaptureDt DT="date" IND="17" LSP="0" MNL="8" MXL="8" PL="8" PRE="mandatory">20180510</CaptureDt><FuncCode DT="numeric" IND="24" LSP="0" MNL="3" MXL="3" PL="3" PRE="mandatory">200</FuncCode><AcqInstIdenCode DT="numeric" IND="32" LSP="2" MNL="1" MXL="11" PL="6" PRE="mandatory">504642</AcqInstIdenCode><INR DT="alphabet" IND="49" LSP="0" MNL="3" MXL="3" PL="3" PRE="mandatory">INR</INR><AccNum DT="alphabetnumericspaces" IND="102" LSP="2" MNL="1" MXL="38" PL="" PRE="mandatory">"""+ acc_num +"""</AccNum><DeliveryChannelCtrlID DT="alphabetnumericspecial" IND="123" LSP="3" MNL="1" MXL="999" PL="3" PRE="mandatory">TLB</DeliveryChannelCtrlID></XML>"""
	print("Input is: ", input_query)
	response = call_api(input_query)
	print("Response is: ", response)
	account_balance = parse_account_balance(response)
	#account_balance = "1413"
	print("Account balance is: ", account_balance)
	return account_balance

def recharge_mobile(mobile_number, amount, account_number):
	user_id = get_user_id(mobile_number)    
	account_number = "ICI"+"        "+str(account_numbers[0])[0:4]+"    "+str(account_numbers[0])
	print("User id: ", user_id)
	print("Account number: ", account_number)	
	input_query = """<XML><HEADER MSGFORMATID="157" PASSTHROUGH="N" ROUTEHOSTTYPE="UBPS" ROUTETO="UBPS" SCRIPTNAME="com.mphasis.businessScripts.bin.ChangeAttribute"></HEADER><MessageType DEFAULT="1200" DT="numeric" LSP="0" MNL="4" MXL="4" PL="4" PRE="mandatory">1200</MessageType><ProcCode DEFAULT="961100" DT="numeric" IND="3" LSP="0" MNL="6" MXL="6" PL="6" PRE="mandatory">961100</ProcCode><TxnAmt DT="numeric" IND="4" LSP="0" MNL="16" MXL="16" PL="16" PRE="optional">"""+amount+"""</TxnAmt><STAN DT="alphabetnumericspaces" IND="11" LSP="0" MNL="12" MXL="12" PL="12" PRE="mandatory">000151182800</STAN><LocalTxnDtTime DT="numeric" IND="12" LSP="0" MNL="14" MXL="14" PL="14" PRE="mandatory">20160808151651</LocalTxnDtTime><CaptureDt DT="date" IND="17" LSP="0" MNL="8" MXL="8" PL="8" PRE="optional">20160808</CaptureDt><FuncCode DT="numeric" IND="24" LSP="0" MNL="3" MXL="3" PL="" PRE="mandatory">200</FuncCode><AcqInstIdenCode DT="numeric" IND="32" LSP="2" MNL="1" MXL="11" PL="" PRE="mandatory">504642</AcqInstIdenCode><Identification1 MXL="28" MNL="1" DT="alphabetnumeric" PL="" LSP="2" IND="34" PRE="mandatory">MONU141</Identification1><RRNNumber DT="numeric" IND="37" LSP="0" MNL="12" MXL="12" PL="12" PRE="mandatory">120809133559</RRNNumber><CardAccTerminalID DT="alphabetnumericspaces" IND="41" LSP="0" MNL="16" MXL="16" PL="16" PRE="optional">UBPS</CardAccTerminalID><CardAccIdentification DT="alphabetnumericspaces" IND="42" LSP="0" MNL="15" MXL="15" PL="15" PRE="optional">504642</CardAccIdentification><CardAccNameLocation DT="alphabetnumericspaces" IND="43" LSP="2" MNL="1" MXL="99" PL="" PRE="optional">UBPS</CardAccNameLocation><Currency DT="alphabetnumeric" IND="49" LSP="0" MNL="3" MXL="3" PL="" PRE="mandatory">INR</Currency><PrivateField DT="alphabetnumericspecialspaces" IND="60" LSP="3" MNL="01" MXL="999" PL="" PRE="optional"></PrivateField><PrivateField2 DT="alphabetnumericspecialspaces" IND="61" LSP="3" MNL="01" MXL="999" PL="" PRE="optional"></PrivateField2><ConsumerNumber DT="alphabetnumericspecialspaces" IND="63" LSP="3" MNL="01" MXL="999" PL="" PRE="optional">"""+mobile_number+"""</ConsumerNumber><AcctIdentificationOne DT="alphabetnumericspecialspaces" IND="102" LSP="2" MNL="01" MXL="38" PL="" PRE="mandatory">"""+account_number+"""</AcctIdentificationOne><DeliveryChannelCtrlID DT="alphabet" IND="123" LSP="3" MNL="1" MXL="3" PL="" PRE="mandatory">IMB</DeliveryChannelCtrlID><AddDataPvt125 DT="alphabetnumericspecialspaces" IND="125" LSP="3" MNL="1" MXL="999" PL="" PRE="optional" RLI="0"><UbpsReqTyp DT="alphabetnumeric" IND="125" LSP="0" MNL="2" MXL="2" PL="" PRE="optional">11</UbpsReqTyp><ScheduleBegngDate DT="alphabetnumericspaces" IND="125" LSP="0" MNL="8" MXL="8" PL="" PRE="optional">00000000</ScheduleBegngDate><PayementFrequency DT="numeric" IND="125" LSP="0" MNL="1" MXL="1" PL="" PRE="optional">0</PayementFrequency><TotNoOfPymnts DT="numeric" IND="125" LSP="0" MNL="5" MXL="5" PL="" PRE="optional">00001</TotNoOfPymnts><PayeeID DT="alphabetnumericspecialspaces" IND="125" LSP="0" MNL="12" MXL="12" PL="" PRE="optional">000000000230</PayeeID><PaymntRemrks DT="alphabetnumericspecialspaces" IND="125" LSP="0" MNL="254" MXL="254" PL="" PRE="optional">Hi</PaymntRemrks><BillRefInfo DT="alphabetnumericspecialspaces" IND="125" LSP="0" MNL="254" MXL="254" PL="" PRE="optional">TOPUP-VODMU20-</BillRefInfo><ValidationFlag DT="alphabetnumericspecialspaces" IND="125" LSP="0" MNL="1" MXL="1" PL="" PRE="optional">A</ValidationFlag><PersonalPayee DT="alphabetnumericspecialspaces" IND="125" LSP="0" MNL="1" MXL="1" PL="" PRE="optional"></PersonalPayee><PayeeNick DT="alphabetnumericspecialspaces" IND="125" LSP="0" MNL="40" MXL="40" PL="" PRE="optional"></PayeeNick><ConsumerCode DT="alphabetnumericspecialspaces" IND="125" LSP="0" MNL="64" MXL="64" PL="" PRE="optional">"""+mobile_number+"""</ConsumerCode></AddDataPvt125></XML>"""
	print("Request is: ", input_query)
	response = call_api(input_query)
	print("Recharge api response is: ", response)
	acc_code = parse_recharge_mobile(response)  
	print("acc code is: ", acc_code) 
	return acc_code

def get_bill_connections(mobile_number, type_of_connection):
	user_id = get_user_id(mobile_number)
	bill_connections = ["Mahanagar Connection","Vivanagar Connection"]
	return bill_connections

def pay_bill(mobile_number, connection_id):
	user_id = get_user_id(mobile_number)
	response = "1"
	return response

def get_payees(mobile_number):
	#user_id = get_user_id(mobile_number)
	user_id = "RIB11XTEST"
	input_query = """<XML>
	<HEADER>UBPS</HEADER>
	<MessageType>1200</MessageType>
	<ProcCode>960800</ProcCode>
	<TxnAmt>0</TxnAmt>
	<STAN>20141216006</STAN>
	<LocalTxnDtTime>00180207075531</LocalTxnDtTime>
	<CaptureDt>20180207</CaptureDt>
	<FuncCode>200</FuncCode>
	<AcqInstIdenCode>504642</AcqInstIdenCode>
	<Identification1>RIB11XTEST</Identification1>
	<Currency>INR</Currency>
	<ConsumerNo />
	<AcctIdentificationOne>                                      </AcctIdentificationOne>
	<DeliveryChannelCtrlID>IMB</DeliveryChannelCtrlID>
	<AddDataPvt125>
		<UbpsReqTyp>08</UbpsReqTyp>
		<PayeeID />
		<InstancePymntDate />
		<ScheduleId></ScheduleId>
		<NoOfPayements>12</NoOfPayements>
		<PaymentType> </PaymentType>
	</AddDataPvt125>
</XML>"""
	response = call_api(input_query)
	print("Response is: ", response)

def get_last_transactions(credit_card_number, mobile_number):
	last_4_digit = ""
	for d in credit_card_number:
		print(d)
		if d.isdigit():
			last_4_digit+=d
	print("Last 4 ditits", last_4_digit)
	credit_card_numbers = get_credit_card_numbers_original(mobile_number)
	print("NNNNNNNNNNNNNNN", credit_card_numbers)
	for cc in credit_card_numbers:
		if cc[-4:] == last_4_digit:
			credit_card_number = cc
	print("Num is: ", credit_card_number)
	input_query = """<XML><MessageType MXL='4' MNL='4' PL='4' DT='numeric' LSP='0' PRE='mandatory' DEFAULT='1200'>1200</MessageType><CustID MXL='19' MNL='19' DT='numeric' PL='19' LSP='0' IND='2' PRE='mandatory'>"""+credit_card_number+"""</CustID><ProcCode MXL='6' MNL='6' PL='6' DT='numeric' LSP='0' IND='3' PRE='mandatory' DEFAULT='610000'>610000</ProcCode><TxnAmt MXL='16' MNL='16' DT='numeric' PL='16' LSP='0' IND='4' PRE='mandatory'>1</TxnAmt><STAN MXL='6' MNL='6' DT='numeric' PL='6' LSP='0' IND='11' PRE='mandatory'>123456</STAN><LocalTxnDtTime MXL='12' MNL='12' DT='numeric' PL='12' LSP='0' IND='12' PRE='mandatory'>20180129152948</LocalTxnDtTime><CaptureDt MXL='8' MNL='8' DT='numeric' PL='' LSP='0' IND='17' PRE='mandatory'>19991015</CaptureDt><FuncCode MXL='3' MNL='3' DT='numeric' PL='' LSP='0' IND='24' PRE='mandatory' OVERRIDE='200'>200</FuncCode><AcqInstIdenCode MXL='11' MNL='1' DT='numeric' PL='' LSP='2' IND='32' PRE='mandatory' OVERRIDE='010'>001</AcqInstIdenCode><Currency MXL='3' MNL='3' DT='alphabet' PL='' LSP='0' IND='49' PRE='mandatory' DEFAULT='INR'>INR</Currency><FaxNo MXL='999' MNL='1' DT='alphabetnumericspecialspaces' PL='' LSP='3' IND='59' PRE='optional' /><FourDigitYear MXL='999' MNL='1' DT='alphabetnumericspecial' PL='' LSP='3' IND='62' PRE='mandatory'>1999</FourDigitYear><ConsumerNo MXL='28' MNL='1' DT='alphabetnumericspaces' PL='' LSP='2' IND='63' PRE='optional'>1</ConsumerNo><AcctIdentificationOne MXL='38' MNL='1' DT='alphabetnumericspaces' PL='' LSP='2' IND='102' PRE='mandatory'>"""+credit_card_number+"""</AcctIdentificationOne><DeliveryChannelCtrlID MXL='3' MNL='3' DT='alphabet' PL='' LSP='0' IND='123' PRE='mandatory' OVERRIDE='INT'>CCI</DeliveryChannelCtrlID><AddDataPvt125 MXL='999' MNL='1' DT='alphabetnumericspecialspaces' PL='' LSP='3' IND='125' RLI='0' PRE='optional'><RecordFrom MXL='999' MNL='1' DT='numeric' PRE='optional' PL='' LSP='1' IND='125'>1</RecordFrom><NoofRecordRequested MXL='99' MNL='1' DT='numeric' PRE='optional' PL='' LSP='1' IND='125'>16</NoofRecordRequested></AddDataPvt125></XML>"""
	print("Request is ", input_query)
	response = call_api(input_query)
	print("Request is: ", input_query)
	print("Response is: ", response)
	print("Okay")

	last_transactions = parse_last_transactions(response)
	return last_transactions
