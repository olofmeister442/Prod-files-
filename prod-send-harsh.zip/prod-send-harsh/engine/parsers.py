import calendar
import csv
import logging
import random
from datetime import date, timedelta
import editdistance
import xmltodict
import pandas as pd
import math
import requests
import json
import uuid
import datetime
import socket

from pprint import pprint
from bs4 import BeautifulSoup

from django.conf import settings
from django.http import HttpResponse
from django.utils.encoding import smart_str
from rest_framework.authentication import (BasicAuthentication,
                                           SessionAuthentication)
from rest_framework.response import Response
from django.shortcuts import render, get_object_or_404
from rest_framework.views import APIView
from django.core.mail import EmailMultiAlternatives
from django.utils.safestring import SafeData, SafeText, mark_safe
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.views import generic
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator

from .models import *
from .constants import *

def parse_user_id(response):
	soup = BeautifulSoup(response)
	userids = soup.findAll("bayuserid")
  
	if len(userids) < 0 or len(userids) == 0:
		return "-5"       # Error Code 5, User Not Found

	if len(userids) == 1:
		#print("".join(userids[0].strings))
		return "".join(userids[0].strings)

	if len(userids) > 1:
		return "-5"       # Error Code 6, Multiple Users Returned

def parse_otp_send(response):
	soup = BeautifulSoup(response)
	actcode = soup.findAll("actcode")
	print("ACT CODE: ", actcode)
	#print("Soup: ", soup)
	if len(actcode) < 0 or len(actcode) == 0:
		return "-5"       # Error Code 5, User Not Found

	if len(actcode) == 1:
		#print("".join(userids[0].strings))
		return "".join(actcode[0].strings)

	if len(actcode) > 1:
		return "-5"       # Error Code 6, Multiple Users Returned

		
def parse_payee_ids_amount(response, type_of_payee):
    soup = BeautifulSoup(response)
    print(soup)
    instanceamts = soup.findAll("instanceamt")
    payeenames = soup.findAll("payeename")
    consumerids = soup.findAll("consumerid")
    
    payee_name_list = []
    for i in range(len(payeenames)):
        temp = "".join(payeenames[i].strings)
        temp2 = "".join(instanceamts[i].strings)
        temp3 = "".join(consumerids[i].strings)
        print(temp)
        temp_tuple = (temp,temp2,temp3,type_of_payee)
        payee_name_list.append(temp_tuple)
    print(payee_name_list)
    return payee_name_list

def parse_payee_ids(response):
    soup = BeautifulSoup(response)
    print(soup)
    payee_ids = soup.findAll("payeeid")
    print(payee_ids)
    payee_id_list = []
    for payee in payee_ids:
        temp = "".join(payee.strings)
        print(temp)
        payee_id_list.append(temp)
    print(payee_id_list)
    return payee_id_list
	
def parse_last_transactions(response):
	soup = BeautifulSoup(response)
	TransactionDesc = soup.findAll("transactiondesc")
	AmountSpentWithdrawn = soup.findAll("amountspentwithdrawn")

	if len(TransactionDesc) < 0 or len(TransactionDesc) == 0:
		return "Sorry, there are no past transactions"

	if len(TransactionDesc) <= 5:
		message = "Here are the details of your last "+ str(len(TransactionDesc)) +" transactions."
	else:
		message = "Here are the details of your last 5 transactions."

	cnt = 0
	for i in range(len(TransactionDesc)):		
		if cnt > 5:
			break
		desc = TransactionDesc[i]
		amt = AmountSpentWithdrawn[i]
		message+="Transaction Description: "+"".join(desc.strings)+" Amount: "+"".join(amt.strings)+" . "
		cnt = cnt + 1
	return message


def parse_account_numbers(response):
        response = response[response.find("<PvtDataField125")+1:response.find("</PvtDataField125>")]
	soup = BeautifulSoup(response)

	fsids = soup.findAll("fsid")
	account_numbers = soup.findAll("accnum")

	linked_account_numbers = []

	if len(fsids) < 0 or len(fsids) == 0:
		return "-5"       # Error Code 5, No Account Number
        
        print("All the fsids are: ", fsids, len(fsids))
        print("Account numbers are: ", account_numbers, len(account_numbers))
        #return None
	for i in range(len(fsids)):
		fsid = fsids[i]
		accnum = account_numbers[i]
		accnum_text = "".join(accnum.strings)
	
		fsid_text = "".join(fsid.strings)

		if(fsid_text=="2") and accnum_text[4:6] == "01":
			linked_account_numbers.append(accnum_text)

	return linked_account_numbers

def parse_credit_card_numbers(response):
	response = response[response.find("<PvtDataField125")+1:response.find("</PvtDataField125>")]
        print(response)
	soup = BeautifulSoup(response)

	fsids = soup.findAll("fsid")
	account_numbers = soup.findAll("accnum")

	linked_credit_card_numbers = []

	if len(fsids) < 0 or len(fsids) == 0:
		return "-5"       # Error Code 5, No Account Number

	for i in range(len(fsids)):
		fsid = fsids[i]
		accnum = account_numbers[i]

		fsid_text = "".join(fsid.strings)
		accnum_text = "".join(accnum.strings)

		if(fsid_text=="3"):
			linked_credit_card_numbers.append(accnum_text)

	return linked_credit_card_numbers

def parse_account_balance(response):
	soup = BeautifulSoup(response)

	account_balance = soup.findAll("availbal")
	
	if len(account_balance) < 0 or len(account_balance) == 0:
		return "-5"       # Error Code 5, No Account Number

	if len(account_balance) > 1:
		return "-5"       # Error Code 6, Multiple Users Returned
	
	return "".join(account_balance[0].strings)

def parse_cc_date_amount(response):
        print("Enteres")
	soup = BeautifulSoup(response)

	tad = soup.findAll("tad")
        print("TAD IS: ", tad)
	if len(tad) < 0 or len(tad) == 0:
		return ("-5","-5")       # Error Code 5, No Tad
	
	if len(tad) > 1:
		return ("-5","-5")       # Error Code 6, Multiple Tad Returned
	
	due_amount = "".join(tad[0].strings)
        print("Due amount is: ", due_amount)
	due_date = soup.findAll("paymentduedate")
        print("due_date is: ", due_date)
	if len(due_date) < 0 or len(due_date) == 0:
		return ("-5","-5")       # Error Code 5, No Due date
	
	if len(due_date) > 1:
		return ("-5","-5")       # Error Code 6, Multiple Due Date Returned

	due_date = "".join(due_date[0].strings)
        print("Extracted due date sis: ", due_date)
	return (due_date, due_amount)
	
def parse_pay_creditcard_bill(response):
	soup = BeautifulSoup(response)

	actcode = soup.findAll("actcode")

	if len(actcode) < 0 or len(actcode) == 0:
		return "-5"       # Error Code 5, No Tad
	
	if len(actcode) > 1:
		return "-5"       # Error Code 6, Multiple Tad Returned
	
	act_code = "".join(actcode[0].strings)

	return act_code

def parse_recharge_mobile(response):
	soup = BeautifulSoup(response)
	actcode = soup.findAll("actcode")

	if len(actcode) < 0 or len(actcode) == 0:
		return "-5"       # Error Code 5, No Tad
	
	if len(actcode) > 1:
		return "-5"       # Error Code 6, Multiple Tad Returned
	
	act_code = "".join(actcode[0].strings)

	return act_code

