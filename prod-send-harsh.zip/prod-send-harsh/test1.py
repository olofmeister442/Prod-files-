from engine.apis import *
from engine.parsers import *
from random import randint
mobile_number = "9930218869"
account_number = "004001608501"
creditcard_number = "4055331016803004"
creditcard_number_2 = "3004"

get_user_id(mobile_number)
print("get_user_id working")

#get_account_numbers_original(mobile_number)
print("account numbers fetched with original and is working")

#get_account_numbers(mobile_number)
print("account numbers fetched with ending with and is working")

#get_credit_card_numbers_original(mobile_number)
print("credit card numbers fetched with original and is working")

#get_credit_card_numbers(mobile_number)
print("credit card numbers fetched with ending with and is working")

#recharge_mobile(mobile_number, "1")
print("recharge mobile api, to still check once more, input money is in paise")

#get_balance(account_number, mobile_number)
print("get_balance api, working, available balance is in paise")

#get_credit_card_details(creditcard_number_2, mobile_number)
print("get_credit_card_details, working, due date in yyyymmdd, due amount in paise and if negative then first char negative else its positive ")
print("cust_id from response")

#pay_credit_card_bill(mobile_number, creditcard_number_2)
print("pay credit card bill working")

#get_payees(mobile_number)
print("get_payees")

#get_last_transactions(creditcard_number_2, mobile_number)

import requests

def random_with_N_digits(n):
    range_start = 10 ** (n - 1)
    range_end = 10 ** n - 1
    return str(randint(range_start, range_end))

import requests
mobile_number = "8169392028"
headers = {'content-type': 'text/xml', 'SOAPAction': ''}
url = \
	'http://10.50.81.32:9001/OTPEngine/services/OTPWebService?wsdl'
unique1 = "12128"
unique2 = "121299"
body = \
	"""<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ws="http://ws.otp.icicibank.com">
<soapenv:Header/>
<soapenv:Body>
<ws:otpService>
 <ws:input><![CDATA[<REQUEST><ACTCODE/><CHANNEL>5</CHANNEL><APPLICATION_NAME>67</APPLICATION_NAME><FIELD1>""" \
	+ unique1 + """</FIELD1><FIELD2>""" + unique2 \
	+ """</FIELD2><FIELD3>SWOPNA</FIELD3><AMOUNT>0.0</AMOUNT><TRANSACTION_CODE>127</TRANSACTION_CODE><VALIDITY>0</VALIDITY><DELIVERY_MODE>SMS</DELIVERY_MODE><DELIVERY_ADDRESS>""" \
	+ mobile_number \
	+ """</DELIVERY_ADDRESS><MANAGED_BY/><ACTION>C</ACTION><OTP/><VALIDITY_GIVEN/></REQUEST>]]>  
</ws:input>
</ws:otpService>
</soapenv:Body>
</soapenv:Envelope>"""
print (body)


#response = requests.post(url, data=body, headers=headers)
#print response.text

reg_mob_no = mobile_number
otp = "841877"
body = """<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ws="http://ws.otp.icicibank.com">
		   <soapenv:Header/>
		   <soapenv:Body>
			  <ws:otpService>
				 <ws:input>
		<![CDATA[<REQUEST>   <ACTCODE/>   <CHANNEL>5</CHANNEL>   <APPLICATION_NAME>67</APPLICATION_NAME>   <FIELD1>"""+unique1+"""</FIELD1>   <FIELD2>"""+unique2+"""</FIELD2>   <FIELD3>SWOPNA</FIELD3>   <AMOUNT>0.0</AMOUNT>   <TRANSACTION_CODE>127</TRANSACTION_CODE>   <VALIDITY>0</VALIDITY>   <DELIVERY_MODE>SMS</DELIVERY_MODE>   <DELIVERY_ADDRESS>"""+reg_mob_no+"""</DELIVERY_ADDRESS>   <MANAGED_BY/>   <ACTION>V</ACTION>   <OTP>"""+otp+"""</OTP>   <VALIDITY_GIVEN/> </REQUEST>]]> 
		</ws:input>
			  </ws:otpService>
		   </soapenv:Body>
		</soapenv:Envelope>"""
print(body)		
#response = requests.post(url, data=body, headers=headers, timeout=7)
#print response.text

#get_grid_response("",account_number,"54","03","33")
