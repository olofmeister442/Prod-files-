class Ideone
{
	public String sendMessage(String ipAddress, String port, String timeOut, String request) 
	    { 
	        Socket socket = null; 
	        StringBuffer inps=null; 
	        DataOutputStream dos =null; 
	        try 
	        { 
	            inps = new StringBuffer(); 
	            logger.info("Connecting to server :Request is: " +request); 
	            socket = new Socket(ipAddress,Integer.parseInt(port)); 
	            logger.info("Successfully Connected to  "+socket); 
	            socket.setSoTimeout(Integer.parseInt(timeOut)); 

	            byte[] bytearry=request.getBytes(); 
	            dos = new DataOutputStream(socket.getOutputStream()); 
	            dos.write(bytearry); 
	            dos.flush(); 
	            boolean isRunning = true; 

	            while(isRunning) 
	            { 
	                 InputStream ins = socket.getInputStream(); 
	                 int i; 
	                    while((i = ins.read()) != -1){ 
	                        inps.append((char)i); 
	                        if(ins.available() == 0){ 
	                            break; 
	                        } 
	                    } 
	                    ins.close(); 
	                  break; 
	            } 

	        } 
	        catch(SocketTimeoutException e) 
	        { 
	            logger.error("Timeout while sending packet to OSB Service: " , e ); 
	        } 
	        catch(IOException e) 
	        { 
	            logger.error("IOException while sending packet to OSB Service: " , e ); 
	        } 
	        catch(Exception e) 
	        { 
	            logger.error("Exception while sending packet to OSB Service: " , e ); 
	        } 
	        finally{ 
	            try { 
	                dos.close(); 
	                socket.close(); 
	            } catch (Exception e) { 
	                logger.error("Exception while releasing resources",e); 
	            } 
	        } 
	        logger.info("Response from server for "+sourceSytemName+" :response is: " +inps.toString()); 
	        return inps.toString(); 
	    } 

	public static void main (String[] args) throws java.lang.Exception
	{
		public String ip = "";
		public String port = "";
		public String timeout = "";
		public String request = "";
		sendMessage(ip, port, timeout, request);
	}
}



